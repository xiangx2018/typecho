<?php
// 归档页
if (!defined('__TYPECHO_ROOT_DIR__'))
    exit;

?>

