<?php

if (!defined('__TYPECHO_ROOT_DIR__'))
    exit;

?>


<div class="fixed h-10 w-full z-50">
    <div class="top-container mx-auto bg-white dark:bg-[#262626] bg-opacity-70 h-10 shadow-lg">
        <span class="ico-back h-10 w-10 flex items-center justify-center go-back"></span>
    </div>
</div>